#aulas do segundo trimeste
nome: Vinícius Yudi Kondo - 31
